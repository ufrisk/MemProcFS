#!/usr/bin/env python3
#
# Author:
#  Tamas Jos (@skelsec)
#
# TODO: MSD article is missing on this stream :(